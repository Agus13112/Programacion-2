package ar.com.cultivos.dao;

import ar.com.cultivos.entities.Cosecha;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ICosechaDao extends JpaRepository<Cosecha, Integer> {
    Page<Cosecha> findAll (Pageable pageable);
}
