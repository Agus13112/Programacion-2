package ar.com.cultivos.services;

import ar.com.cultivos.entities.Plantaciones;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IPlantacionesService {
    List<Plantaciones> getAll();
    Plantaciones get(Integer id);
    void save(Plantaciones entity);
    String delete(Plantaciones entity);
    Page<Plantaciones> findAll(Pageable pageable);
}
