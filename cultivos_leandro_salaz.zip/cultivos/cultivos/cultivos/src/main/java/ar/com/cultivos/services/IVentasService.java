package ar.com.cultivos.services;

import ar.com.cultivos.entities.Ventas;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IVentasService {
    List<Ventas> getAll();
    Ventas get(Integer id);
    void save(Ventas entity);
    String delete(Ventas entity);
    Page<Ventas> findAll(Pageable pageable);
}
