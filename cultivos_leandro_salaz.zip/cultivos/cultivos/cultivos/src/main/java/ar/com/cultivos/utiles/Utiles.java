package ar.com.cultivos.utiles;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

public class Utiles {

    public Date getFechaActual() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Calendar cal = Calendar.getInstance();

        String date = dateFormat.format(cal.getTime());

        try {
            Date s = dateFormat.parse(date);
            return s;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Date getFechaHoraActual() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Calendar cal = Calendar.getInstance();

        String date = dateFormat.format(cal.getTime());

        try {
            Date s = dateFormat.parse(date);
            return s;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String getUUID() {
        return UUID.randomUUID().toString().replace("-", "");
    }
}
