package ar.com.cultivos.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "cosecha")
public class Cosecha implements Serializable {
    private static final long serialVersionUID= 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private LocalDate fecha;
    @JoinColumn(name = "fk_plantaciones", referencedColumnName = "id", nullable = false)
    @ManyToOne
    private Plantaciones plantaciones;
    private String rendimiento;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Plantaciones getPlantaciones() {
        return plantaciones;
    }

    public void setPlantaciones(Plantaciones plantaciones) {
        this.plantaciones = plantaciones;
    }

    public String getRendimiento() {
        return rendimiento;
    }

    public void setRendimiento(String rendimiento) {
        this.rendimiento = rendimiento;
    }
}
