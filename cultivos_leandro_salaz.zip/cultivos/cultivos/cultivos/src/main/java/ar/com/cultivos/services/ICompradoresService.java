package ar.com.cultivos.services;

import ar.com.cultivos.entities.Compradores;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ICompradoresService {
    List<Compradores> getAll();
    Page<Compradores> findAll(Pageable pageable);
    List<Compradores> findByDescrip(String nombre);
    Compradores get(Integer id);
    void save(Compradores entity);
    String delete(Compradores entity);
}
