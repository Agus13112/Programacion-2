package ar.com.cultivos.services;

import ar.com.cultivos.entities.Cosecha;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ICosechaService {
    List<Cosecha> getAll();
    Cosecha get(Integer id);
    void save(Cosecha entity);
    String delete(Cosecha entity);
    Page<Cosecha> findAll(Pageable pageable);
}
