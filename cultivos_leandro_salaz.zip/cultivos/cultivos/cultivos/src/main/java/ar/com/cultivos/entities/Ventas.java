package ar.com.cultivos.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "ventas")
public class Ventas implements Serializable {
    private static final long serialVersionUID= 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private LocalDate fecha;

    @JoinColumn(name = "fk_plantaciones", referencedColumnName = "id", nullable = false)
    @ManyToOne
    private Plantaciones plantaciones;

    @JoinColumn(name = "fk_comprador", referencedColumnName = "id", nullable = false)
    @ManyToOne
    private Compradores compradores;
    private Double cantidadvendida;
    private Double precio;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public Plantaciones getPlantaciones() {
        return plantaciones;
    }

    public void setPlantaciones(Plantaciones plantaciones) {
        this.plantaciones = plantaciones;
    }

    public Compradores getCompradores() {
        return compradores;
    }

    public void setCompradores(Compradores compradores) {
        this.compradores = compradores;
    }

    public Double getCantidadvendida() {
        return cantidadvendida;
    }

    public void setCantidadvendida(Double cantidadvendida) {
        this.cantidadvendida = cantidadvendida;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
}
