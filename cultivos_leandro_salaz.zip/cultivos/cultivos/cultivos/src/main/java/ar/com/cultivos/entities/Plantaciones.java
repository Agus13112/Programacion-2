package ar.com.cultivos.entities;

import jakarta.persistence.*;

import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "plantaciones")
public class Plantaciones implements Serializable {
    private static final long serialVersionUID =1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String periodo;
    private LocalDate fecha;

    @JoinColumn(name = "fk_cultivo", referencedColumnName = "id", nullable = false)
    @ManyToOne
    private Cultivos cultivo;

    @JoinColumn(name = "fk_lotes", referencedColumnName = "id", nullable = false)
    @ManyToOne
    private Lotes lote;

    private float porcentajeslote;
    private LocalDate fechacierre;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }




    public Cultivos getCultivo() {
        return cultivo;
    }

    public void setCultivo(Cultivos cultivo) {
        this.cultivo = cultivo;
    }

    public Lotes getLote() {
        return lote;
    }

    public void setLote(Lotes lote) {
        this.lote = lote;
    }

    public float getPorcentajeslote() {
        return porcentajeslote;
    }

    public void setPorcentajeslote(float porcentajeslote) {
        this.porcentajeslote = porcentajeslote;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public LocalDate getFechacierre() {
        return fechacierre;
    }

    public void setFechacierre(LocalDate fechacierre) {
        this.fechacierre = fechacierre;
    }
}


