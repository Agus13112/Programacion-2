package ar.com.cultivos.services;

import ar.com.cultivos.entities.Gastos;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IGastosService {
    List<Gastos> getAll();
    Gastos get(Integer id);
    void save(Gastos entity);
    String delete(Gastos entity);
    Page<Gastos> findAll(Pageable pageable);
}
