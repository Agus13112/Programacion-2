package ar.com.cultivos.config;

import ar.com.cultivos.dao.IUsuariosDao;
import ar.com.cultivos.entities.Usuarios;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

	private final IUsuariosDao userRepository;

	public WebSecurityConfig(IUsuariosDao userRepository) {
		this.userRepository = userRepository;
	}


	@Bean
	public UserDetailsService userDetailsService() {
		return username -> {
			Usuarios user = userRepository.findOneByUsername(username);
			if (user == null) {
				throw new UsernameNotFoundException("Usuario no encontrado: " + username);
			}

			return org.springframework.security.core.userdetails.User
					.withUsername(user.getUsername())
					.password(user.getPassword()) // debe estar encriptada con BCrypt
					.roles(user.getRol().getDescrip().toUpperCase()) // ej: ADMIN, VENDEDOR
					.disabled(Boolean.TRUE.equals(user.getInactivo()))
					.build();
		};
	}



	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}


	@Bean
	public AuthenticationManager authManager(UserDetailsService userDetailsService, PasswordEncoder encoder) {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		provider.setUserDetailsService(userDetailsService);
		provider.setPasswordEncoder(encoder);
		return new ProviderManager(provider);
	}


	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		http
				.csrf(csrf -> csrf.disable())
				.authorizeHttpRequests(auth -> auth
						.requestMatchers("/global/**", "/static/**", "/css/**", "/js/**", "/images/**").permitAll()
						.requestMatchers("/", "/home").authenticated()
						.anyRequest().authenticated()
				)
				.formLogin(form -> form
						.loginPage("/login")
						.defaultSuccessUrl("/", true)
						.permitAll()
				)
				.logout(logout -> logout.permitAll())
				.httpBasic(httpBasic -> {});
		return http.build();
	}
}
