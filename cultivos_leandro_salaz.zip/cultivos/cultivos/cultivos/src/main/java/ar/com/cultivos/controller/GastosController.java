package ar.com.cultivos.controller;

import ar.com.cultivos.entities.Cosecha;
import ar.com.cultivos.entities.Gastos;
import ar.com.cultivos.entities.Plantaciones;
import ar.com.cultivos.services.IGastosService;
import ar.com.cultivos.services.IPlantacionesService;
import ar.com.cultivos.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class GastosController {
    @Autowired
    IGastosService entityService;
    @Autowired
    IPlantacionesService plantacionesService;

    @RequestMapping(value = "/gastos", method = RequestMethod.GET)
    //public String list(Model model, Pageable pageable) {
    public String list(Model model,
                       @PageableDefault(size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {

        Page<Gastos> centroPage = entityService.findAll(pageable);
        PageWrapper<Gastos> page = new PageWrapper<Gastos>(centroPage, "/gastos");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Gastos());
        return "../gastos/index";
    }

    @RequestMapping("/gastos/refresh")
    public String refresh() {
        return "redirect:/gastos";
    }


    @RequestMapping(value = "/gastos/search", method = RequestMethod.POST)
    public String search(Model model, Cosecha entity) {
        if (entity.getFecha() == null || entity.getFecha().equals("")) {
            return refresh();
        }

        model.addAttribute("entity", new Gastos());
        model.addAttribute("page", null);
        return "../gastos/index";
    }

    @RequestMapping("/gastos/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Gastos());
        List<Plantaciones> list = plantacionesService.getAll();
        model.addAttribute("plantaciones", list);

        //  List<Lotes> lista = loteService.getAll();
        //  model.addAttribute("lotes", lista);


        return "../gastos/edit";
    }

    @RequestMapping("/gastos/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Plantaciones> list = plantacionesService.getAll();
        model.addAttribute("plantaciones", list);


        //  List<Lotes> lista = loteService.getAll();
        //   model.addAttribute("lotes", lista);
        return "../gastos/edit";
    }

    @RequestMapping(value = "/gastos", method = RequestMethod.POST)
    public String save(Model model, @Validated Gastos entity) {
        String errores = "";
        // if (entity.getUsername().equals("")) errores += "Usuario Incorrecto ";
        //if (entity.getPassorig().equals("")) errores += "Password Incorrecto ";

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Plantaciones> list = plantacionesService.getAll();
            model.addAttribute("plantaciones", list);

            // List<Lotes> lista = loteService.getAll();
            // model.addAttribute("lotes", lista);
            return "../gastos/edit";
        }

        entityService.save(entity);
        return "redirect:/gastos";
    }


    @RequestMapping("gastos/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Gastos entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/gastos";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Gastos> centroPage = entityService.findAll(pageable);
            PageWrapper<Gastos> page = new PageWrapper<Gastos>(centroPage, "/cosecha");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Cosecha());
            return "../gastos/index";
        }
    }
}
