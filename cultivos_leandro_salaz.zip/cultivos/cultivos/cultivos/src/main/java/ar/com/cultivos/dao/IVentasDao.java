package ar.com.cultivos.dao;

import ar.com.cultivos.entities.Ventas;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IVentasDao extends JpaRepository<Ventas, Integer> {
    Page<Ventas> findAll (Pageable pageable);
}
