package ar.com.cultivos.controller;
import ar.com.cultivos.entities.*;
import ar.com.cultivos.services.ICultivosService;
import ar.com.cultivos.services.ILotesService;
import ar.com.cultivos.services.IPlantacionesService;
import ar.com.cultivos.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class PlantacionesController {
    @Autowired
    IPlantacionesService entityService;
    @Autowired
    ICultivosService cultivoService;
    @Autowired
    ILotesService loteService;

    @RequestMapping(value = "/plantaciones", method = RequestMethod.GET)
    //public String list(Model model, Pageable pageable) {
    public String list(Model model,
                       @PageableDefault(size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {

        Page<Plantaciones> centroPage = entityService.findAll(pageable);
        PageWrapper<Plantaciones> page = new PageWrapper<Plantaciones>(centroPage, "/plantaciones");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Plantaciones());
        return "../plantaciones/index";
    }

    @RequestMapping("/plantaciones/refresh")
    public String refresh() {
        return "redirect:/plantaciones";
    }


    @RequestMapping(value = "/plantaciones/search", method = RequestMethod.POST)
    public String search(Model model, Plantaciones entity) {
      //  if (entity.getFecha().equals("")) {
       //     return refresh();
        if (entity.getFecha() == null || entity.getFecha().equals("")) {
            return refresh();
        }
      //  model.addAttribute("entities", entityService.findByDescrip(entity.getUsername()));
        model.addAttribute("entity", new Plantaciones());
        model.addAttribute("page", null);
        return "../plantaciones/index";
    }

    @RequestMapping("/plantaciones/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Plantaciones());
        List<Cultivos> list = cultivoService.getAll();
        model.addAttribute("cultivos", list);

        List<Lotes> lista = loteService.getAll();
        model.addAttribute("lotes", lista);


        return "../plantaciones/edit";
    }

    @RequestMapping("/plantaciones/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Cultivos> list = cultivoService.getAll();
        model.addAttribute("cultivos", list);


        List<Lotes> lista = loteService.getAll();
        model.addAttribute("lotes", lista);
        return "../plantaciones/edit";
    }

    @RequestMapping(value = "plantaciones", method = RequestMethod.POST)
    public String save(Model model, @Validated Plantaciones entity) {
        String errores = "";
       // if (entity.getUsername().equals("")) errores += "Usuario Incorrecto ";
        //if (entity.getPassorig().equals("")) errores += "Password Incorrecto ";

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Cultivos> list = cultivoService.getAll();
            model.addAttribute("cultivos", list);

            List<Lotes> lista = loteService.getAll();
            model.addAttribute("lotes", lista);
            return "../plantaciones/edit";
        }

        entityService.save(entity);
        return "redirect:/plantaciones";
    }

    @RequestMapping("plantaciones/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Plantaciones entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/plantaciones";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Plantaciones> centroPage = entityService.findAll(pageable);
            PageWrapper<Plantaciones> page = new PageWrapper<Plantaciones>(centroPage, "/plantaciones");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Plantaciones());
            return "../plantaciones/index";
        }
    }
}
