package ar.com.cultivos.controller;

import ar.com.cultivos.entities.*;
import ar.com.cultivos.services.*;
import ar.com.cultivos.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class VentasController {
    @Autowired
    IVentasService entityService;
    @Autowired
    ICompradoresService compradoresService;
    @Autowired
    IPlantacionesService plantacionesService;

    @RequestMapping(value = "/ventas", method = RequestMethod.GET)
    //public String list(Model model, Pageable pageable) {
    public String list(Model model,
                       @PageableDefault(size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {

        Page<Ventas> centroPage = entityService.findAll(pageable);
        PageWrapper<Ventas> page = new PageWrapper<Ventas>(centroPage, "/ventas");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Ventas());
        return "../ventas/index";
    }

    @RequestMapping("/ventas/refresh")
    public String refresh() {
        return "redirect:/ventas";
    }


    @RequestMapping(value = "/ventas/search", method = RequestMethod.POST)
    public String search(Model model, Plantaciones entity) {
        //  if (entity.getFecha().equals("")) {
        //     return refresh();
        if (entity.getFecha() == null || entity.getFecha().equals("")) {
            return refresh();
        }
        //  model.addAttribute("entities", entityService.findByDescrip(entity.getUsername()));
        model.addAttribute("entity", new Ventas());
        model.addAttribute("page", null);
        return "../ventas/index";
    }


    @RequestMapping("/ventas/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Ventas());
        List<Compradores> list = compradoresService.getAll();
        model.addAttribute("compradores", list);

        List<Plantaciones> lista = plantacionesService.getAll();
        model.addAttribute("plantaciones", lista);


        return "../ventas/edit";
    }

    @RequestMapping("/ventas/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Compradores> list = compradoresService.getAll();
        model.addAttribute("compradores", list);


        List<Plantaciones> lista = plantacionesService.getAll();
        model.addAttribute("plantaciones", lista);
        return "../ventas/edit";
    }

    @RequestMapping(value = "ventas", method = RequestMethod.POST)
    public String save(Model model, @Validated Ventas entity) {
        String errores = "";
        // if (entity.getUsername().equals("")) errores += "Usuario Incorrecto ";
        //if (entity.getPassorig().equals("")) errores += "Password Incorrecto ";

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Compradores> list = compradoresService.getAll();
            model.addAttribute("compradores", list);

            List<Plantaciones> lista = plantacionesService.getAll();
            model.addAttribute("plantaciones", lista);
            return "../ventas/edit";
        }

        entityService.save(entity);
        return "redirect:/ventas";
    }

    @RequestMapping("ventas/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Ventas entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/ventas";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Ventas> centroPage = entityService.findAll(pageable);
            PageWrapper<Ventas> page = new PageWrapper<Ventas>(centroPage, "/ventas");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Ventas());
            return "../ventas/index";
        }
    }




}
