package ar.com.cultivos.controller;

import ar.com.cultivos.entities.Compradores;
import ar.com.cultivos.services.ICompradoresService;
import ar.com.cultivos.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
public class CompradoresController {
    @Autowired
    ICompradoresService entityService;

    @RequestMapping(value = "/compradores", method = RequestMethod.GET)
    public String list(Model model, Pageable pageable) {
        Page<Compradores> centroPage = entityService.findAll(pageable);
        PageWrapper<Compradores> page = new PageWrapper<Compradores>(centroPage, "/compradores");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Compradores());
        return "../compradores/index";
    }

    @RequestMapping("compradores/refresh")
    public String refresh() { return "redirect:/compradores";}

    @RequestMapping(value = "compradores/search", method = RequestMethod.POST)
    public String search(Model model, Compradores entity, Pageable pageable) {
        if (entity.getNombre().equals("")) {
            return refresh();
        }
        model.addAttribute("entities", entityService.findByDescrip(entity.getNombre()));
        model.addAttribute("entity", new Compradores());
        model.addAttribute("page", null);
        return "../compradores/index";

    }

    @RequestMapping("compradores/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Compradores());
        return "../compradores/edit";
    }


    @RequestMapping("compradores/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        return "../compradores/edit";
    }

    @RequestMapping(value = "compradores", method = RequestMethod.POST)
    public String save(Model model, @Validated Compradores entity) {
        if (entity.getNombre().equals("")) {
            model.addAttribute("message", "Descripción Incorrecta");
            model.addAttribute("entity", entity);
            return "../compradores/edit";
        }

        entityService.save(entity);
        return "redirect:/compradores";
    }

    @RequestMapping("compradores/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Compradores entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/compradores";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Compradores> centroPage = entityService.findAll(pageable);
            PageWrapper<Compradores> page = new PageWrapper<Compradores>(centroPage, "/compradores");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Compradores());
            return "../compradores/index";
        }
    }


}
