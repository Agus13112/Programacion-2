package ar.com.cultivos.controller;

import ar.com.cultivos.entities.Cosecha;
import ar.com.cultivos.entities.Plantaciones;
import ar.com.cultivos.services.ICosechaService;
import ar.com.cultivos.services.IPlantacionesService;
import ar.com.cultivos.utiles.PageWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

@Controller
public class CosechaController {
    @Autowired
    ICosechaService  entityService;
    @Autowired
    IPlantacionesService plantacionesService;


    @RequestMapping(value = "/cosecha", method = RequestMethod.GET)
    //public String list(Model model, Pageable pageable) {
    public String list(Model model,
                       @PageableDefault(size = 10, sort = "id", direction = Sort.Direction.ASC) Pageable pageable) {

        Page<Cosecha> centroPage = entityService.findAll(pageable);
        PageWrapper<Cosecha> page = new PageWrapper<Cosecha>(centroPage, "/cosecha");
        model.addAttribute("entities", page.getContent());
        model.addAttribute("page", page);
        model.addAttribute("entity", new Cosecha());
        return "../cosecha/index";
    }

    @RequestMapping("/cosecha/refresh")
    public String refresh() {
        return "redirect:/cosecha";
    }


    @RequestMapping(value = "/cosecha/search", method = RequestMethod.POST)
    public String search(Model model, Cosecha entity) {
        if (entity.getFecha() == null || entity.getFecha().equals("")) {
            return refresh();
        }

        model.addAttribute("entity", new Cosecha());
        model.addAttribute("page", null);
        return "../cosecha/index";
    }

    @RequestMapping("/cosecha/create/{id}")
    public String create(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", new Cosecha());
        List<Plantaciones> list = plantacionesService.getAll();
        model.addAttribute("plantaciones", list);

      //  List<Lotes> lista = loteService.getAll();
      //  model.addAttribute("lotes", lista);


        return "../cosecha/edit";
    }

    @RequestMapping("/cosecha/edit/{id}")
    public String edit(@PathVariable Integer id, Model model) {
        model.addAttribute("entity", entityService.get(id));
        List<Plantaciones> list = plantacionesService.getAll();
        model.addAttribute("plantaciones", list);


      //  List<Lotes> lista = loteService.getAll();
     //   model.addAttribute("lotes", lista);
        return "../cosecha/edit";
    }


    @RequestMapping(value = "/cosecha", method = RequestMethod.POST)
    public String save(Model model, @Validated Cosecha entity) {
        String errores = "";
        // if (entity.getUsername().equals("")) errores += "Usuario Incorrecto ";
        //if (entity.getPassorig().equals("")) errores += "Password Incorrecto ";

        if (!errores.equals("")) {
            model.addAttribute("message", errores);
            model.addAttribute("entity", entity);
            List<Plantaciones> list = plantacionesService.getAll();
            model.addAttribute("plantaciones", list);

           // List<Lotes> lista = loteService.getAll();
            // model.addAttribute("lotes", lista);
            return "../cosecha/edit";
        }

        entityService.save(entity);
        return "redirect:/cosecha";
    }

    @RequestMapping("cosecha/delete/{id}")
    public String delete(@PathVariable Integer id, Model model, Pageable pageable) {
        try {
            Cosecha entity = entityService.get(id);
            entityService.delete(entity);
            return "redirect:/cosecha";
        } catch (Exception e) {
            model.addAttribute("message", e.getMessage().toString());
            Page<Cosecha> centroPage = entityService.findAll(pageable);
            PageWrapper<Cosecha> page = new PageWrapper<Cosecha>(centroPage, "/cosecha");
            model.addAttribute("entities", page.getContent());
            model.addAttribute("page", page);
            model.addAttribute("entity", new Cosecha());
            return "../cosecha/index";
        }
    }



}
