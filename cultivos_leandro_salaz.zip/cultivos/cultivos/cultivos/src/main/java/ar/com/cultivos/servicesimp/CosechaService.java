package ar.com.cultivos.servicesimp;

import ar.com.cultivos.dao.ICosechaDao;
import ar.com.cultivos.entities.Cosecha;
import ar.com.cultivos.services.ICosechaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class CosechaService implements ICosechaService {
    @Autowired
    private ICosechaDao entityDao;

    public List<Cosecha> getAll() {
        return entityDao.findAll(Sort.by(Sort.Direction.ASC, "fecha"));
    }


    public Page<Cosecha> findAll(Pageable pageable) {
        return entityDao.findAll(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), Sort.by(Sort.Direction.ASC, "fecha")));
    }

    public Cosecha get(Integer id) {
        return entityDao.findById(id).orElse(null);
    }


    @Transactional
    public void save(Cosecha entity) {
        //BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        entity.setFecha(entity.getFecha());
        entityDao.save(entity);


    }

    @Transactional
    public String delete(Cosecha entity) {
        try {
            entityDao.delete(entity);
            return null;
        } catch (Exception e) {
            return e.getMessage().toString();
        }
    }

}
